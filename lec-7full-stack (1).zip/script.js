var input = document.getElementById('input')
var ol = document.getElementById('ol')
var temaplate = document.getElementById('template')

  ol.append(template.content.cloneNode(true).querySelector('li'))

function addTask(task) {
  // debugger
  var li = document.createElement('LI')
  var taskName = document.createElement('div')
  taskName.innerText = task.name || input.value
  li.append(taskName)

  var duration = document.createElement('i')
  duration.innerText = task.duration
  duration.style.color = 'blue'
  li.append(duration)
 
  var status = document.createElement('button')
  status.innerText = task.status
  status.addEventListener('click', event => {
	event.stopPropagation()
	if(status.innerText == 'pending'){
  	status.innerText = 'done'
	}
	else if(status.innerText == 'done'){
  	status.innerText = 'pending'
	}
  })
  li.append(status)
  li.style.display = 'flex'
  li.style.gap = '10px'
  // debugger
  // status.style.marginLeft = 'auto'
  var deleteButton = document.createElement('button')
  deleteButton.innerText = 'x'
  deleteButton.addEventListener('click', event => {
	event.stopPropagation()
	removeTask(li)
  })

  li.append(deleteButton)

  var editButton = document.createElement('button')
  editButton.innerText = '✎'
  editButton.addEventListener('click', function(event){
	event.stopPropagation()
	editTask(event, li)
  })
  li.append(editButton)
 
  ol.append(li)
  li.addEventListener('click', editTask)
  input.value = ''
}

var selectedTask
function editTask(event, task) {

  event.stopPropagation()
  // input.value = event.target.innerText
  input.value = task.children[0].innerText

  if (selectedTask) {
	selectedTask.style.background = ''
	selectedTask.style.border = ''
  }
 
  task.style.background = 'yellow'
  task.style.border = '1px solid green'
  selectedTask = task

}

function updateTask() {
  selectedTask.innerText = input.value
  input.value = ''
  //alert('updated')
}
function removeTask(task){
  if(confirm('Are you sure?')){
	var item = task.type == 'li' ? task : task.parentNode
	ol.removeChild(item)
  }
}

function deleteTask() {

  if (selectedTask) {
	ol.removeChild(selectedTask)
	input.value = ''
  }

}


// let tasksArray = [
//   'First Task',
//   'Second Task',
//   'Third Task',
//   'Task 4',
//   'Task 05'
// ]

let tasksArray = [
  {name:'The First Task', status:'pending', duration:0},
  {name:'Even Task No 2', status:'done', duration:2.5},
  {name:'Thrid Task', status:'done', duration:2.5},
  {name:'Task No Four', status:'done', duration:2.5}
]


for (var index = 0; index < tasksArray.length; index++ /* increment, opposite decrement */) {
  addTask(tasksArray[index])

  // debugger
}
// debugger

// tasksArray.map(item => {
//   addTask('the task mapped from the array - ' + item)
// })
